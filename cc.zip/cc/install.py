;import os

os.system('pip install --upgrade pip')
os.system('pip3 install requests pysocks colorama')

print('install success!')
